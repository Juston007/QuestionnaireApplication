package com.jnxxgc.answerclient.net;

public class HttpEngine {

	public static String serverUrl = "";
	public static String AccessToken = "";
}
